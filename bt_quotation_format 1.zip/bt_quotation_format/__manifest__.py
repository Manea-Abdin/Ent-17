# -*- coding: utf-8 -*-
{
    "name": "Quotation",
    "version": "17.0.0.0",
    "author": "Biztras",
    'website': 'https://biztras.com/',
    "category": "Tax invoice Report",
    "description": """Tax invoice Report""",
    "depends": ['sale_management'],
    'data': [
        'reports/quotation_header.xml',
        'reports/quotation_report.xml',

    ],
    "application": False,

}
