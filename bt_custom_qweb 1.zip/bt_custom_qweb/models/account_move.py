from odoo import api, fields, models, _
from googletrans import Translator
import re


class ResCompany(models.Model):
    _inherit = 'res.company'

    account_name = fields.Char('Account Name')
    bank_name = fields.Char('Bank Name')
    bank_country = fields.Many2one('res.country','Bank Country')
    account_no = fields.Char('Account Number')
    iban = fields.Char('IBAN')
    swift = fields.Char('SWIFT')
    branch = fields.Char('Branch Name')

