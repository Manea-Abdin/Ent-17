{
    'name': 'Invoice Report',
    'summary': 'Invoice Report',
    'version': '17.0.0.0.0',
    'category': 'Accounting',
    'website': 'https://www.biztras.com/',
    'author': "Biztras",
    'license': 'AGPL-3',
    'application': False,
    'installable': True,
    'depends': [
        'account', 'l10n_ae', 'base'
    ],
    'data': [
        'views/account_move.xml',
        'reports/invoice.xml',
    ],
}
