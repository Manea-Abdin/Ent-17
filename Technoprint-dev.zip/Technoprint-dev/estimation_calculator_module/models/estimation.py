# -*- coding: utf-8 -*-

from datetime import date
from datetime import datetime
from odoo.exceptions import UserError, ValidationError
from odoo import models, fields, api, _
from odoo.addons import decimal_precision as dp


class SaleOrder(models.Model):
    _inherit = "sale.order"

    estimation_id = fields.Many2one('job.costing')
    job_cost_id = fields.Many2one('job.costing', string='Estimation', readonly=True, copy=False )

    def action_view_crm(self):
        self.ensure_one()
        job_obj = self.env['crm.lead']
        cost_ids = job_obj.search([('id', '=', self.opportunity_id.id)]).ids
        action = {
            'type': 'ir.actions.act_window',
            'name': 'CRM',
            'res_model': 'crm.lead',
            'res_id': self.id,
            'domain': [('id','in',cost_ids)],
            'view_type': 'form',
            'view_mode': 'tree,form',
            'target': self.id,
        }
        return action


class JobCosting(models.Model):
    _name = 'job.costing'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']  # odoo11
    #    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _description = "Job Costing"
    _rec_name = 'number'

    @api.model
    def create(self, vals):
        number = self.env['ir.sequence'].next_by_code('job.costing')
        vals.update({
            'number': number,
        })

        # if 'calculation_method_material' in vals and vals['calculation_method_material'] == 'percentage':
        #     if vals['perc_material'] and vals.get('job_cost_line_ids', False):
        #         for cline in vals['job_cost_line_ids']:
        #             cline[2].update(
        #                 {'margin': (cline[2]['product_qty'] * cline[2]['cost_price']) * (vals['perc_material'] / 100)})
        # if 'calculation_method_material' in vals and vals['calculation_method_material'] == 'lumsum':
        #     if vals['lumsum_material'] and vals.get('job_cost_line_ids', False):
        #         material_total = sum([(p[2]['product_qty'] * p[2]['cost_price']) for p in vals['job_cost_line_ids']])
        #
        #         for cline in vals['job_cost_line_ids']:
        #             if material_total:
        #                 cline[2]['margin'] = (float(vals['lumsum_material'] / material_total) * (
        #                         cline[2]['product_qty'] * cline[2]['cost_price']))
        #     if not vals['lumsum_material']:
        #         raise ValidationError(_('Please fill up the lumsum amount.'))
        #
        # if vals['calculation_method_overhead'] == 'percentage':
        #     if vals['perc_overhead'] and vals.get('job_overhead_line_ids', False):
        #         for cline in vals['job_overhead_line_ids']:
        #             cline[2].update(
        #                 {'margin': (cline[2]['product_qty'] * cline[2]['cost_price']) * (vals['perc_overhead'] / 100)})
        #
        # if vals['calculation_method_overhead'] == 'lumsum':
        #     if vals['lumsum_overhead'] and vals.get('job_overhead_line_ids', False):
        #         overhead_total = sum(
        #             [(p[2]['product_qty'] * p[2]['cost_price']) for p in vals['job_overhead_line_ids']])
        #
        #         for cline in vals['job_overhead_line_ids']:
        #             if overhead_total:
        #                 cline[2]['margin'] = (float(vals['lumsum_overhead'] / overhead_total) * (
        #                         cline[2]['product_qty'] * cline[2]['cost_price']))
        #     if not vals['lumsum_overhead']:
        #         raise ValidationError(_('Please fill up the lumsum amount.'))
        #
        # if vals['calculation_method_labour'] == 'percentage':
        #     if vals['perc_labour'] and vals.get('job_labour_line_ids', False):
        #
        #         for cline in vals['job_labour_line_ids']:
        #             cline[2]['margin'] = (cline[2]['hours'] * cline[2]['cost_price']) * (vals['perc_labour'] / 100)
        #
        # if vals['calculation_method_labour'] == 'lumsum':
        #     if vals['lumsum_labour'] and vals.get('job_labour_line_ids', False):
        #         labour_total = sum([(p[2]['hours'] * p[2]['cost_price']) for p in vals['job_labour_line_ids']])
        #
        #         for cline in vals['job_labour_line_ids']:
        #             if labour_total:
        #                 cline[2]['margin'] = (float(vals['lumsum_labour'] / labour_total) * (
        #                         cline[2]['hours'] * cline[2]['cost_price']))
        #             else:
        #                 cline[2].update({'margin': vals['lumsum_labour']})
        #     if not vals['lumsum_labour']:
        #         raise ValidationError(_('Please fill up the lumsum amount.'))
        result = super(JobCosting, self).create(vals)
        return result

    def _write(self, vals):
        for self1 in self:
            res = super(JobCosting, self1)._write(vals)
            # if self1.calculation_method_material == 'percentage':
            #     if self1.perc_material:
            #         for cline in self1.job_cost_line_ids:
            #             cline.margin = (cline.product_qty * cline.cost_price) * (cline.direct_id.perc_material / 100)
            #
            # if self1.calculation_method_material == 'lumsum':
            #     if self1.lumsum_material:
            #         material_total = sum([(p.product_qty * p.cost_price) for p in self1.job_cost_line_ids])
            #         for cline in self1.job_cost_line_ids:
            #             if material_total:
            #                 cline.margin = (float(cline.direct_id.lumsum_material / cline.direct_id.material_total) * (
            #                         cline.product_qty * cline.cost_price))
            #
            # if self1.calculation_method_material == 'linewise':
            #     for cline in self1.job_cost_line_ids:
            #         cline.margin_total = (cline.product_qty * cline.cost_price) + cline.margin
            #
            # if self1.calculation_method_material == 'line_by_per':
            #     for lab in self1.job_cost_line_ids:
            #         lab.margin_total = (lab.margin / 100 * lab.total_cost) + lab.total_cost
            #
            # if self1.calculation_method_labour == 'percentage':
            #     if self1.perc_labour:
            #         for cline in self1.job_labour_line_ids:
            #             cline.margin = (cline.hours * cline.cost_price) * (cline.direct_id.perc_labour / 100)
            #
            # if self1.calculation_method_labour == 'lumsum':
            #     if self1.lumsum_labour:
            #         labour_total = sum([(p.hours * p.cost_price) for p in self1.job_labour_line_ids])
            #         for cline in self1.job_labour_line_ids:
            #             if labour_total:
            #                 cline.margin = (
            #                         float(self1.lumsum_labour / labour_total) * (cline.hours * cline.cost_price))
            #
            # if self1.calculation_method_labour == 'linewise':
            #     for cline in self1.job_labour_line_ids:
            #         cline.margin_total = (cline.hours * cline.cost_price) + cline.margin
            #
            # if self1.calculation_method_labour == 'line_by_per':
            #     for lab in self1.job_labour_line_ids:
            #         lab.margin_total = (lab.margin / 100 * lab.total_cost) + lab.total_cost
            #
            # if self1.calculation_method_overhead == 'percentage':
            #     if self1.perc_overhead:
            #         for cline in self1.job_overhead_line_ids:
            #             cline.margin = (cline.product_qty * cline.cost_price) * (cline.direct_id.perc_overhead / 100)
            #
            # if self1.calculation_method_overhead == 'lumsum':
            #     if self1.lumsum_overhead:
            #         labour_total = sum([(p.product_qty * p.cost_price) for p in self1.job_overhead_line_ids])
            #         for cline in self1.job_overhead_line_ids:
            #             if labour_total:
            #                 cline.margin = (float(self1.lumsum_overhead / labour_total) * (
            #                         cline.product_qty * cline.cost_price))
            #
            # if self1.calculation_method_overhead == 'linewise':
            #     for cline in self1.job_overhead_line_ids:
            #         cline.margin_total = (cline.product_qty * cline.cost_price) + cline.margin
            #
            # if self1.calculation_method_overhead == 'line_by_per':
            #     for lab in self1.job_overhead_line_ids:
            #         lab.margin_total = (lab.margin / 100 * lab.total_cost) + lab.total_cost

            return res



    @api.depends(
        'job_impress_line_id',
        'job_impress_line_id.product_qty',
        'job_impress_line_id.cost_price',
    )
    def _compute_impress_total(self):
       for rec in self:
            rec.impress_total = sum([(p.product_qty * p.cost_price) for p in rec.job_impress_line_id])


    @api.depends(
        'job_cost_line_ids',
        'job_cost_line_ids.product_qty',
        'job_cost_line_ids.cost_price',
    )
    def _compute_material_total(self):
        for rec in self:
            rec.material_total = sum([(p.product_qty * p.cost_price) for p in rec.job_cost_line_ids])

    @api.depends(
        'job_labour_line_ids',
        'job_labour_line_ids.hours',
        'job_labour_line_ids.cost_price'
    )
    def _compute_labor_total(self):
        for rec in self:
            rec.labor_total = sum([(p.hours * p.cost_price) for p in rec.job_labour_line_ids])

    @api.depends(
        'job_overhead_line_ids',
        'job_overhead_line_ids.product_qty',
        'job_overhead_line_ids.cost_price'
    )
    def _compute_overhead_total(self):
        for rec in self:
            rec.overhead_total = sum([(p.product_qty * p.cost_price) for p in rec.job_overhead_line_ids])

    @api.depends(
        'job_cost_line_ids',
        'job_cost_line_ids.product_qty',
        'job_cost_line_ids.cost_price',
    )
    def _compute_jobcost_total_material(self):
        for rec in self:
            rec.jobcost_total_material = sum([(p.margin_total) for p in rec.job_cost_line_ids])

    @api.depends(
        'job_labour_line_ids',
        'job_labour_line_ids.hours',
        'job_labour_line_ids.cost_price'
    )
    def _compute_jobcost_total_labour(self):
        for rec in self:
            rec.jobcost_total_labour = sum([(p.margin_total) for p in rec.job_labour_line_ids])

    @api.depends(
        'job_overhead_line_ids',
        'job_overhead_line_ids.product_qty',
        'job_overhead_line_ids.cost_price'
    )
    def _compute_jobcost_total_overhead(self):
        for rec in self:
            rec.jobcost_total_overhead = sum([(p.margin_total) for p in rec.job_overhead_line_ids])

    @api.depends(
        'material_total',
        'labor_total',
        'overhead_total'
    )
    def _compute_jobcost_total(self):
        for rec in self:
            rec.jobcost_total = rec.material_total + rec.labor_total + rec.overhead_total

    @api.depends(
        'jobcost_total_material',
        'jobcost_total_labour',
        'jobcost_total_overhead'
    )
    def _compute_total(self):
        for rec in self:
            rec.total = rec.jobcost_total_material + rec.jobcost_total_labour + rec.jobcost_total_overhead

    @api.depends(
        'jobcost_total_material',
        'jobcost_total_labour',
        'jobcost_total_overhead',
        'material_total',
        'labor_total',
        'overhead_total'
    )
    def _compute_tot(self):
        for rec in self:
            rec.total_m = self.jobcost_total_material - self.material_total
            rec.total_l = self.jobcost_total_labour - self.labor_total
            rec.total_o = self.jobcost_total_overhead - self.overhead_total
            rec.mtotal = self.total - self.jobcost_total

    #     @api.multi
    #     def _purchase_order_line_count(self):
    #         purchase_order_lines_obj = self.env['purchase.order.line']
    #         for order_line in self:
    #             order_line.purchase_order_line_count = purchase_order_lines_obj.search_count([('job_cost_id','=',order_line.id)])
    #
    #     @api.multi
    #     def _timesheet_line_count(self):
    #         hr_timesheet_obj = self.env['account.analytic.line']
    #         for timesheet_line in self:
    #             timesheet_line.timesheet_line_count = hr_timesheet_obj.search_count([('job_cost_id', '=', timesheet_line.id)])
    #
    #     @api.multi
    #     def _account_invoice_line_count(self):
    #         account_invoice_lines_obj = self.env['account.invoice.line']
    #         for invoice_line in self:
    #             invoice_line.account_invoice_line_count = account_invoice_lines_obj.search_count([('job_cost_id', '=', invoice_line.id)])

    @api.constrains('perc_material', 'perc_labour', 'perc_overhead')
    def _check_field(self):
        if self.perc_material:
            if self.perc_material < 0.00 or self.perc_material > 100.00:
                raise ValidationError(_('The amount of Percentage in material is not correct.'))
        if self.perc_labour:
            if self.perc_labour < 0.00 or self.perc_labour > 100.00:
                raise ValidationError(_('The amount of Percentage in labour is not correct.'))
        if self.perc_overhead:
            if self.perc_overhead < 0.00 or self.perc_overhead > 100.00:
                raise ValidationError(_('The amount of  Percentage in overhead is not correct.'))
        return True

    #     @api.onchange('project_id')
    #     def _onchange_project_id(self):
    #         for rec in self:
    #             rec.analytic_id = rec.project_id.analytic_account_id.id
    #
    number = fields.Char(
        readonly=True,
        default='New',
        copy=False,
    )
    name = fields.Char(
        required=True,
        copy=True,
        default='New',
        string='Name',
    )
    notes_job = fields.Text(
        required=False,
        copy=True,
        string='Job Cost Details'
    )
    user_id = fields.Many2one(
        'res.users',
        default=lambda self: self.env.user,
        string='Created By',
        readonly=True
    )
    lead_id = fields.Many2one(
        'crm.lead',
        string='CRM',
        readonly=True
    )

    description = fields.Char(
        string='Description',
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.user.company_id.currency_id,
        readonly=True
    )
    company_id = fields.Many2one(
        'res.company',
        default=lambda self: self.env.user.company_id,
        string='Company',
        readonly=True
    )
    #     project_id = fields.Many2one(
    #         'project.project',
    #         string='Project',
    #     )
    analytic_id = fields.Many2one(
        'account.analytic.account',
        string='Analytic Account')

    contract_date = fields.Date(
        string='Contract Date',
    )
    start_date = fields.Date(
        string='Create Date',
        readonly=True,
        default=fields.Date.today(),
    )
    complete_date = fields.Date(
        string='Closed Date',
        readonly=True,
    )
    material_total = fields.Float(
        string='Total Material Cost',
        compute='_compute_material_total',

    )
    impress_total = fields.Float(
        string='Total Impress Cost',
        compute='_compute_impress_total',

    )
    labor_total = fields.Float(
        string='Total Resources Cost',
        compute='_compute_labor_total',
    )
    overhead_total = fields.Float(
        string='Total Overhead Cost',
        compute='_compute_overhead_total',
    )
    jobcost_total = fields.Float(
        store=True,
        string='Total Cost',
        compute='_compute_jobcost_total',
    )
    total = fields.Float(
        string='Total',
        compute='_compute_total',
    )

    jobcost_total_material = fields.Float(
        string='Total Cost',
        compute='_compute_jobcost_total_material',
    )
    jobcost_total_overhead = fields.Float(
        string='Total Cost',
        compute='_compute_jobcost_total_overhead',
    )
    jobcost_total_labour = fields.Float(
        string='Total Cost',
        compute='_compute_jobcost_total_labour',
    )
    job_cost_line_ids = fields.One2many(
        'job.cost.line',
        'direct_id',
        string='Direct Materials',
        domain=[('job_type', '=', 'material')],
    )
    job_labour_line_ids = fields.One2many(
        'job.labour.line',
        'direct_id',
        string='Direct Materials',
        domain=[('job_type', '=', 'labour')],
    )
    job_overhead_line_ids = fields.One2many(
        'job.overhead.line',
        'direct_id',
        string='Direct Materials',
        domain=[('job_type', '=', 'overhead')],
    )
    job_impress_line_id = fields.One2many(
        'job.imp.line',
        'direct_id',
        string='impression',
        domain=[('job_type', '=', 'material')],
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer',
        required=True,
        domain=[('customer_rank', '>', 0)],
    )
    #     task_id = fields.Many2one(
    #         'project.task',
    #         string='Job Order',
    #     )
    so_number = fields.Char(
        string='Sale Reference'
    )
    calculation_method_material = fields.Selection(
        selection=[('percentage', 'Total percentage margin'),
                   ('lumsum', 'Total lumsum margin'),
                   ('linewise', 'Linewise margin'),
                   ('line_by_per', 'Line by percenage margin')
                   ], default='percentage',
        copy=True,
        string="Margin calculation method",
    )
    calculation_method_overhead = fields.Selection(
        selection=[('percentage', 'Total percentage margin'),
                   ('lumsum', 'Total lumsum margin'),
                   ('linewise', 'Linewise margin'),
                   ('line_by_per', 'Line by percenage margin')
                   ], default='percentage',
        copy=True,
        string="Margin calculation method",
    )
    calculation_method_labour = fields.Selection(
        selection=[('percentage', 'Total percentage margin'),
                   ('lumsum', 'Total lumsum margin'),
                   ('linewise', 'Linewise margin'),
                   ('line_by_per', 'Line by percenage margin')
                   ], default='percentage',
        copy=True,
        string="Margin calculation method",
    )
    perc_material = fields.Float(
        string='Percent'
    )
    perc_overhead = fields.Float(
        string='Percent'
    )
    perc_labour = fields.Float(
        string='Percent'
    )
    lumsum_material = fields.Float(
        string='Lumsum Amount'
    )
    lumsum_overhead = fields.Float(
        string='Lumsum Amount'
    )
    lumsum_labour = fields.Float(
        string='Lumsum Amount'
    )
    total_m = fields.Float(
        string='Total Cost',
        compute='_compute_tot',
    )
    total_o = fields.Float(
        string='Total Cost',
        compute='_compute_tot',
    )
    total_l = fields.Float(
        string='Total Cost',
        compute='_compute_tot',
    )
    mtotal = fields.Float(
        string='Total Cost',
        compute='_compute_tot',
    )

    state = fields.Selection([
        ('draft', 'Draft'),
        ('submit_r1', 'Submitted to R1 Approval'),
        ('submit_r2', 'Submitted to R2 Approval'),
        ('approve', 'Approve Estimation'),
        ('cancel', 'Cancel'),

    ], string='Status', index=True, readonly=True, default='draft',
        track_visibility='onchange', copy=False, )

    final_product1 = fields.Many2one(
        'product.template',
        string='Final Product', required=True
    )
    quantity = fields.Integer(string="Quantity")

    _constraints = [
        (_check_field, 'Please give proper percentage value.', ['perc_material', 'perc_labour', 'perc_overhead'])
    ]



    def action_done(self):
        #         lines={}
        lst = []

        self.write({
            'state': 'approve',
            'complete_date': date.today(),
        })

    def action_confirm(self):
        for rec in self:
            rec.write({
                'state': 'submit_r2',
            })

    def action_submit(self):
        for rec in self:
            rec.write({
                'state': 'submit_r1',
            })

    def action_cancel(self):
        for rec in self:
            rec.write({
                'state': 'cancel',
            })

    def action_draft(self):
        for rec in self:
            rec.write({
                'state': 'draft',
            })

    def create_rfq(self):
        for rec in self:
            for i in range(1, 6):
                vendor = self.env['res.partner'].search([('name', '=', 'PO Draft')])
                purchase = self.env['purchase.order'].create({'state': 'draft',
                                                              'partner_id': vendor.id,
                                                              'job_cost_id': rec.id,
                                                              })
                for mline in rec.job_cost_line_ids:
                    lines = {}
                    if mline.product_qty:
                        price = mline.product_id.standard_price
                    else:
                        price = 0.00
                    lines = {
                        'product_id': mline.product_id.id,
                        'name': mline.description,
                        'product_qty': mline.product_qty,
                        'order_id': purchase.id,
                        'date_planned': datetime.now(),
                        'product_uom': mline.uom_id.id,
                        'price_unit': price,
                        'account_analytic_id': rec.analytic_id.id
                    }
                    pline = self.env['purchase.order.line'].create(lines)
                    pline.write({'price_unit': price})
                for lline in rec.job_labour_line_ids:
                    lines = {}
                    if lline.hours:
                        price = lline.product_id.standard_price
                    else:
                        price = 0.00
                    lines = {
                        'product_id': lline.product_id.id,
                        'name': lline.description,
                        'product_qty': lline.hours,
                        'price_unit': 1.00,
                        'order_id': purchase.id,
                        'date_planned': datetime.now(),
                        'product_uom': 1,
                        'account_analytic_id': rec.analytic_id.id
                    }
                    pline = self.env['purchase.order.line'].create(lines)
                    pline.write({'price_unit': price})
                for oline in rec.job_overhead_line_ids:
                    lines = {}
                    if oline.product_qty:
                        price = oline.product_id.standard_price
                    else:
                        price = 0.00
                    lines = {
                        'product_id': oline.product_id.id,
                        'name': oline.description,
                        'product_qty': oline.product_qty,
                        'price_unit': price,
                        'order_id': purchase.id,
                        'date_planned': datetime.now(),
                        'product_uom': oline.uom_id.id,
                        'account_analytic_id': rec.analytic_id.id
                    }
                    pline = self.env['purchase.order.line'].create(lines)
                    pline.write({'price_unit': price})
        cost_ids = self.env['purchase.order'].search([('job_cost_id', '=', self.id)]).ids
        action = {
            'type': 'ir.actions.act_window',
            'name': 'Purchase Order',
            'res_model': 'purchase.order',
            'res_id': self.id,
            'domain': "[('id','in',[" + ','.join(map(str, cost_ids)) + "])]",
            'view_type': 'form',
            'view_mode': 'tree,form',
            'target': self.id,
        }
        return action



class JobCostLine(models.Model):
    _name = 'job.cost.line'
    _rec_name = 'description'

    @api.onchange('product_id')
    def _onchange_product_id(self):
        for rec in self:
            rec.description = rec.product_id.name
            rec.product_qty = 1.0
            rec.uom_id = rec.product_id.uom_id.id
            rec.cost_price = rec.product_id.standard_price  # lst_price

    @api.depends('product_qty', 'hours', 'cost_price', 'direct_id')
    def _compute_total_cost(self):
        for rec in self:
            rec.hours = 0.0
            rec.total_cost = rec.product_qty * rec.cost_price

    @api.depends('margin', 'total_cost')
    def _compute_margin_total(self):
        for rec in self:
            if rec.direct_id.calculation_method_material == 'line_by_per':
                rec.margin_total = (rec.margin / 100 * rec.total_cost) + rec.total_cost
            else:
                rec.margin_total = rec.margin + rec.total_cost


    sl_num = fields.Char(
        string='Sl Number',
        copy=False,
    )
    direct_id = fields.Many2one(
        'job.costing',
        string='Job Costing'
    )
    product_id = fields.Many2one(
        'product.product',
        string='Product',
        copy=False,
        required=True,
    )
    description = fields.Char(
        string='Description',
        copy=False,
    )
    reference = fields.Char(
        string='Reference',
        copy=False,
    )
    product_qty = fields.Float(
        string='Planned Qty',
        copy=False,
    )
    uom_id = fields.Many2one(
        'uom.uom',  # product.uom
        string='Uom',
    )
    cost_price = fields.Float(
        string='Cost / Unit',
        copy=False,
    )
    total_cost = fields.Float(
        string='Cost Price Sub Total',
        compute='_compute_total_cost',
        store=True,
    )
    analytic_id = fields.Many2one(
        'account.analytic.account',
        string='Analytic Account',
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.user.company_id.currency_id,
        readonly=True
    )
    #     job_type_id = fields.Many2one(
    #         'job.type',
    #         string='Job Type',
    #     )
    job_type = fields.Selection(
        selection=[('material', 'Material'),
                   ('labour', 'Labour'),
                   ('overhead', 'Overhead')
                   ],
        string="Type",
        required=True,
    )
    basis = fields.Char(
        string='Basis'
    )
    hours = fields.Float(
        string='Hours'
    )
    margin = fields.Float(
        string='Margin',

    )
    margin_total = fields.Float(
        string='Total with Margin',
        compute='_compute_margin_total',
        store=True,
    )

    @api.depends('product_id')
    @api.onchange('product_id')
    def _onchange_product(self):
        for rec in self:
            impress = self.env['product.estimation.type'].search([('name', 'in', ['Product'])]).ids
            rec.product_domain = [('id', 'in', self.env['product.product'].search([('product_estima_type', 'in', impress)]).ids)]

    product_domain = fields.Char(default=_onchange_product)


class JobImprLine(models.Model):
    _name = 'job.imp.line'
    _rec_name = 'description'

    @api.onchange('product_id','product_qty')
    def _onchange_product_id(self):
        for rec in self:
            rec.description = rec.product_id.name
            if not rec.product_qty:
                rec.product_qty = 1.0
            rec.uom_id = rec.product_id.uom_id.id
            cal_obj = self.env['estimation.calculator'].search([('product_id', '=', self.product_id.id)])
            if cal_obj:
                if rec.product_qty <=1000:
                    rec.cost_price = (cal_obj.fixed_one + cal_obj.dynamic_one)/rec.product_qty
                elif rec.product_qty > 1000 and rec.product_qty <= 3000:
                    rec.cost_price = ((rec.product_qty/1000*cal_obj.dynamic_three) + cal_obj.fixed_three)/rec.product_qty
                elif rec.product_qty > 3000 and rec.product_qty <= 5000:
                    rec.cost_price = ((rec.product_qty/1000*cal_obj.dynamic_five) + cal_obj.fixed_five)/rec.product_qty
                elif rec.product_qty > 5000 and rec.product_qty <= 10000:
                    rec.cost_price = ((rec.product_qty/1000*cal_obj.dynamic_ten) + cal_obj.fixed_ten )/rec.product_qty
                elif rec.product_qty > 10000 and rec.product_qty <= 25000:
                    rec.cost_price = ((rec.product_qty/1000*cal_obj.dynamic_twentyfive) + cal_obj.fixed_twentyfive)/rec.product_qty
                elif rec.product_qty >25000 and rec.product_qty <= 50000:
                    rec.cost_price = ((rec.product_qty/1000*cal_obj.dynamic_fifty) + cal_obj.fixed_fifty )/rec.product_qty
                elif rec.product_qty > 50000 and rec.product_qty <= 100000:
                    rec.cost_price = ((rec.product_qty/1000*cal_obj.dynamic_lakh) + cal_obj.fixed_lakh)/rec.product_qty
                elif rec.product_qty > 100000:
                    rec.cost_price = ((rec.product_qty / 1000 * cal_obj.dynamic_lakh_abv) + cal_obj.fixed_lakh_abv) / rec.product_qty
            if not cal_obj and self.product_id:
                raise ValidationError(_('Please Configure Imprint Calculator for the product.'))
    @api.depends('product_qty', 'hours', 'cost_price', 'direct_id')
    def _compute_total_cost(self):
        for rec in self:
            rec.hours = 0.0
            rec.total_cost = rec.product_qty * rec.cost_price

    @api.depends('margin', 'total_cost')
    def _compute_margin_total(self):
        for rec in self:
            if rec.direct_id.calculation_method_material == 'line_by_per':
                rec.margin_total = (rec.margin / 100 * rec.total_cost) + rec.total_cost
            else:
                rec.margin_total = rec.margin + rec.total_cost


    sl_num = fields.Char(
        string='Sl Number',
        copy=False,
    )
    direct_id = fields.Many2one(
        'job.costing',
        string='Job Costing'
    )
    product_id = fields.Many2one(
        'product.product',
        string='Product',
        copy=False,
        required=True,
    )
    description = fields.Char(
        string='Description',
        copy=False,
    )
    reference = fields.Char(
        string='Reference',
        copy=False,
    )
    product_qty = fields.Float(
        string='Planned Qty',
        copy=False,
    )
    uom_id = fields.Many2one(
        'uom.uom',  # product.uom
        string='Uom',
    )
    cost_price = fields.Float(
        string='Cost / Unit',
        copy=False,
    )
    total_cost = fields.Float(
        string='Cost Price Sub Total',
        compute='_compute_total_cost',

    )
    analytic_id = fields.Many2one(
        'account.analytic.account',
        string='Analytic Account',
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.user.company_id.currency_id,
        readonly=True
    )
    #     job_type_id = fields.Many2one(
    #         'job.type',
    #         string='Job Type',
    #     )
    job_type = fields.Selection(
        selection=[('material', 'Material'),
                   ('labour', 'Labour'),
                   ('overhead', 'Overhead')
                   ],
        string="Type",
        required=True,
    )
    basis = fields.Char(
        string='Basis'
    )
    hours = fields.Float(
        string='Hours'
    )
    margin = fields.Float(
        string='Margin',

    )
    margin_total = fields.Float(
        string='Total with Margin',
        compute='_compute_margin_total',
        store=True,
    )


    @api.depends('product_id')
    @api.onchange('product_id')
    def _onchange_product(self):
        for rec in self:
            impress = self.env['product.estimation.type'].search([('name', 'in', ['Impression'])]).ids
            rec.product_domain = [
                ('id', 'in', self.env['product.product'].search([('product_estima_type', 'in', impress)]).ids)]

    product_domain = fields.Char(default=_onchange_product)


class JobOverheadLine(models.Model):
    _name = 'job.overhead.line'
    _rec_name = 'description'

    @api.depends('margin', 'total_cost')
    def _compute_margin_total(self):
        for rec in self:
            if rec.direct_id.calculation_method_overhead == 'line_by_per':
                rec.margin_total = (rec.margin / 100 * rec.total_cost) + rec.total_cost
            else:
                rec.margin_total = rec.margin + rec.total_cost

    @api.onchange('product_id')
    def _onchange_product_id(self):
        for rec in self:
            rec.description = rec.product_id.name
            rec.product_qty = 1.0
            rec.uom_id = rec.product_id.uom_id.id
            rec.cost_price = rec.product_id.standard_price  # lst_price

    @api.depends('product_qty', 'hours', 'cost_price', 'direct_id')
    def _compute_total_cost(self):
        for rec in self:
            if rec.job_type == 'labour':
                rec.product_qty = 0.0
                rec.total_cost = rec.hours * rec.cost_price
            else:
                rec.hours = 0.0
                rec.total_cost = rec.product_qty * rec.cost_price


    sl_num = fields.Char(
        string='Sl Number',
        copy=False,
    )
    direct_id = fields.Many2one(
        'job.costing',
        string='Job Costing'
    )
    product_id = fields.Many2one(
        'product.product',
        string='Product',
        copy=False,
        required=True,
    )
    description = fields.Char(
        string='Description',
        copy=False,
    )
    reference = fields.Char(
        string='Reference',
        copy=False,
    )
    product_qty = fields.Float(
        string='Planned Qty',
        copy=False,
    )
    uom_id = fields.Many2one(
        'uom.uom',  # product.uom
        string='Uom',
    )
    cost_price = fields.Float(
        string='Cost / Unit',
        copy=False,
    )
    total_cost = fields.Float(
        string='Cost Price Sub Total',
        compute='_compute_total_cost',
        store=True,
    )
    analytic_id = fields.Many2one(
        'account.analytic.account',
        string='Analytic Account',
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.user.company_id.currency_id,
        readonly=True
    )

    job_type = fields.Selection(
        selection=[('material', 'Material'),
                   ('labour', 'Labour'),
                   ('overhead', 'Overhead')
                   ],
        string="Type",
        required=True,
    )
    basis = fields.Char(
        string='Basis'
    )
    hours = fields.Float(
        string='Hours'
    )
    margin = fields.Float(
        string='Margin'
    )
    margin_total = fields.Float(
        string='Total with Margin',
        compute='_compute_margin_total',
        store=True,
    )


    @api.depends('product_id')
    @api.onchange('product_id')
    def _onchange_product(self):
        for rec in self:
            impress = self.env['product.estimation.type'].search([('name', 'in', ['Overhead'])]).ids
            rec.product_domain = [('id', 'in', self.env['product.product'].search([('product_estima_type', 'in', impress)]).ids)]

    product_domain = fields.Char(default=_onchange_product)


class JoblabourLine(models.Model):
    _name = 'job.labour.line'
    _rec_name = 'description'

    @api.depends('margin', 'total_cost')
    def _compute_margin_total(self):
        for rec in self:
            if rec.direct_id.calculation_method_labour == 'line_by_per':
                rec.margin_total = (rec.margin / 100 * rec.total_cost) + rec.total_cost
            else:
                rec.margin_total = rec.margin + rec.total_cost

    @api.onchange('product_id')
    def _onchange_product_id(self):
        for rec in self:
            rec.description = rec.product_id.name
            rec.product_qty = 1.0
            rec.uom_id = rec.product_id.uom_id.id
            rec.cost_price = rec.product_id.standard_price  # lst_price

    @api.depends('product_qty', 'hours', 'cost_price', 'direct_id')
    def _compute_total_cost(self):
        for rec in self:
            if rec.job_type == 'labour':
                rec.product_qty = 0.0
                rec.total_cost = rec.hours * rec.cost_price
            else:
                rec.hours = 0.0
                rec.total_cost = rec.product_qty * rec.cost_price


    sl_num = fields.Char(
        string='Sl Number',
        copy=False,
    )
    direct_id = fields.Many2one(
        'job.costing',
        string='Job Costing'
    )
    product_id = fields.Many2one(
        'product.product',
        string='Product',
        copy=False,
        required=True,
    )
    description = fields.Char(
        string='Description',
        copy=False,
    )
    reference = fields.Char(
        string='Reference',
        copy=False,
    )
    product_qty = fields.Float(
        string='Planned Qty',
        copy=False,
    )
    uom_id = fields.Many2one(
        'uom.uom',  # product.uom
        string='Uom',
    )
    cost_price = fields.Float(
        string='Cost / Unit',
        copy=False,
    )
    total_cost = fields.Float(
        string='Cost Price Sub Total',
        compute='_compute_total_cost',
        store=True,
    )
    analytic_id = fields.Many2one(
        'account.analytic.account',
        string='Analytic Account',
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.user.company_id.currency_id,
        readonly=True
    )
    #     job_type_id = fields.Many2one(
    #         'job.type',
    #         string='Job Type',
    #     )
    job_type = fields.Selection(
        selection=[('material', 'Material'),
                   ('labour', 'Labour'),
                   ('overhead', 'Overhead')
                   ],
        string="Type",
        required=True,
    )
    basis = fields.Char(
        string='Basis'
    )
    hours = fields.Float(
        string='Hours'
    )
    margin = fields.Float(
        string='Margin'
    )
    margin_total = fields.Float(
        string='Total with Margin',
        compute='_compute_margin_total',
        store=True,
    )



    @api.depends('product_id')
    @api.onchange('product_id')
    def _onchange_product(self):
        for rec in self:
            impress = self.env['product.estimation.type'].search([('name', 'in', ['Service'])]).ids
            rec.product_domain = [('id', 'in', self.env['product.product'].search([('product_estima_type', 'in', impress)]).ids)]

    product_domain = fields.Char(default=_onchange_product)


# class JobImpressionLine(models.Model):
#     _name = 'job.impression.line'
    #_rec_name = 'description'

    # @api.depends('margin', 'total_cost')
    # def _compute_margin_total(self):
    #     for rec in self:
    #         if rec.direct_id.calculation_method_labour == 'line_by_per':
    #             rec.margin_total = (rec.margin / 100 * rec.total_cost) + rec.total_cost
    #         else:
    #             rec.margin_total = rec.margin + rec.total_cost
    #
    # @api.onchange('product_id')
    # def _onchange_product_id(self):
    #     for rec in self:
    #         rec.description = rec.product_id.name
    #         rec.product_qty = 1.0
    #         rec.uom_id = rec.product_id.uom_id.id
    #         rec.cost_price = rec.product_id.standard_price  # lst_price
    #
    # @api.depends('product_qty', 'hours', 'cost_price', 'direct_id')
    # def _compute_total_cost(self):
    #     for rec in self:
    #         if rec.job_type == 'labour':
    #             rec.product_qty = 0.0
    #             rec.total_cost = rec.hours * rec.cost_price
    #         else:
    #             rec.hours = 0.0
    #             rec.total_cost = rec.product_qty * rec.cost_price


    # sl_num = fields.Char(
    #     string='Sl Number',
    #     copy=False,
    # )
    # direct_id = fields.Many2one(
    #     'job.costing',
    #     string='Job Costing'
    # )
    # product_id = fields.Many2one(
    #     'product.product',
    #     string='Product',
    #     copy=False,
    #     required=True,
    # )
    # description = fields.Char(
    #     string='Description',
    #     copy=False,
    # )
    # reference = fields.Char(
    #     string='Reference',
    #     copy=False,
    # )
    # product_qty = fields.Float(
    #     string='Planned Qty',
    #     copy=False,
    # )
    # uom_id = fields.Many2one(
    #     'uom.uom',  # product.uom
    #     string='Uom',
    # )
    # cost_price = fields.Float(
    #     string='Cost / Unit',
    #     copy=False,
    # )
    # total_cost = fields.Float(
    #     string='Cost Price Sub Total',
    #     compute='_compute_total_cost',
    #     store=True,
    # )
    # analytic_id = fields.Many2one(
    #     'account.analytic.account',
    #     string='Analytic Account',
    # )
    # currency_id = fields.Many2one(
    #     'res.currency',
    #     string='Currency',
    #     default=lambda self: self.env.user.company_id.currency_id,
    #     readonly=True
    # )
    # #     job_type_id = fields.Many2one(
    # #         'job.type',
    # #         string='Job Type',
    # #     )
    # job_type = fields.Selection(
    #     selection=[('material', 'Material'),
    #                ('labour', 'Labour'),
    #                ('overhead', 'Overhead'),
    #                ('impression', 'Impression')
    #                ],
    #     string="Type",
    #     required=True,
    # )
    # basis = fields.Char(
    #     string='Basis'
    # )
    # hours = fields.Float(
    #     string='Hours'
    # )
    # margin = fields.Float(
    #     string='Margin'
    # )
    # margin_total = fields.Float(
    #     string='Total with Margin',
    #     compute='_compute_margin_total',
    #     store=True,
    # )


class Lead(models.Model):
    _inherit = "crm.lead"

    ref = fields.Char(
        string='Client Reference'
    )
    submit_date = fields.Date(
        string='Expected Submission Date',
    )
    lead_source = fields.Many2one(
        'lead.source',
        string='Lead Source',
    )
    lead_details = fields.Char(
        string='Lead Details'
    )

    def action_view_estimations(self):
        self.ensure_one()
        crm_obj = self.env['job.costing']
        cost_ids = crm_obj.search([('lead_id', '=', self.id)]).ids

        action = {
            'type': 'ir.actions.act_window',
            'name': 'CRM',
            'res_model': 'job.costing',
            'res_id': self.id,
            'domain': "[('id','=',[" + ','.join(map(str, cost_ids)) + "])]",
            'view_type': 'form',
            'view_mode': 'tree,form',
            'target': self.id,
        }
        return action


class LeadSource(models.Model):
    _name = "lead.source"

    name = fields.Char(string="Name")


class MrpBom(models.Model):
    _inherit = "mrp.bom"

    estimation_id = fields.Many2one('job.costing')

    def action_manufacturing_order(self):
        vals = {}
        vals['product_id'] = self.product_id.id
        vals['product_qty'] = self.product_qty
        mrp = self.env['mrp.production'].create(vals)

        return {
            'name': 'Manufacturing Order',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'mrp.production',
            'view_id': self.env.ref("mrp.mrp_production_form_view").id,
            'type': 'ir.actions.act_window',
            'res_id': mrp.id,
            'target': 'current',
            'context': {},
        }


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    @api.depends('product_tmpl_id')
    def compute_product(self):
        for rec in self:
            rec.product_template_id = rec.product_tmpl_id

    product_tmpl_id = fields.Many2one('product.template', 'New Product')
    product_template_id = fields.Many2one('product.template', 'Product', compute='compute_product')

    _sql_constraints = [
        ('accountable_required_fields',
         "CHECK(display_type IS NOT NULL OR (product_template_id IS NOT NULL AND product_uom IS NOT NULL))",
         "Missing required fields on accountable sale order line."),
        ('non_accountable_null_fields',
         "CHECK(display_type IS NULL OR (product_id IS NULL AND price_unit = 0 AND product_uom_qty = 0 AND product_uom IS NULL AND customer_lead = 0))",
         "Forbidden values on non-accountable sale order line"),
    ]

class Product(models.Model):
    _inherit = "product.template"


    product_estima_type = fields.Many2one('product.estimation.type', string="Product Estimation Type",required=True,)

    @api.depends('detailed_type','product_estima_type','service_request_domain')
    @api.onchange('detailed_type','product_estima_type','service_request_domain')
    def _onchange_detailed_type(self):
        for rec in self:
            if rec.detailed_type:
                if rec.detailed_type == 'product':
                    est_typ_obj = self.env['product.estimation.type'].search([('name', 'in', ['Product','Impression'])]).ids
                    rec.service_request_domain = [('id', 'in', est_typ_obj)]
                elif rec.detailed_type == 'service':
                    est_typ_obj = self.env['product.estimation.type'].search([('name', 'in', ['Service'])]).ids
                    rec.service_request_domain =  [('id', 'in', est_typ_obj)]
                else:
                    est_typ_obj = self.env['product.estimation.type'].search([('name', 'in', ['Overhead'])]).ids
                    rec.service_request_domain = [('id', 'in', est_typ_obj)]
            else:
                est_typ_obj = self.env['product.estimation.type'].search([]).ids
                rec.service_request_domain = [('id', 'in', est_typ_obj)]


    service_request_domain = fields.Char(default=_onchange_detailed_type,compute ='_onchange_detailed_type')




class ProductEstimationType(models.Model):
    _name = "product.estimation.type"

    name = fields.Char('Name')

class EstimationCalculator(models.Model):
    _name = 'estimation.calculator'
    _rec_name = 'product_id'

    product_id = fields.Many2one(
        'product.product',
        string='Product', required=True,)

    fixed_one = fields.Float('0-1000 Fix Price')
    dynamic_one = fields.Float('0-1000 Dynamic Price')
    fixed_three = fields.Float('1001-3000 Fix Price')
    dynamic_three = fields.Float('1001-3000 Dynamic Price')
    fixed_five = fields.Float('3001-5000 Fix Price')
    dynamic_five = fields.Float('3001-5000 Dynamic Price')
    fixed_ten = fields.Float('5001-10000 Fix Price')
    dynamic_ten = fields.Float('5001-10000 Dynamic Price')
    fixed_twentyfive = fields.Float('10001-25000 Fix Price')
    dynamic_twentyfive = fields.Float('10001-25000 Dynamic Price')
    fixed_fifty = fields.Float('25001-50000 Fix Price')
    dynamic_fifty = fields.Float('25001-50000 Dynamic Price')
    fixed_lakh = fields.Float('50001-100000 Fix Price')
    dynamic_lakh = fields.Float('50001-100000 Dynamic Price')
    fixed_lakh_abv = fields.Float('Above 100001 Fix Price')
    dynamic_lakh_abv = fields.Float('Above 100001 Dynamic Price')

    _sql_constraints = [
        ('product_uniq', 'unique (product_id)', "A record with the same product already exists."),
    ]




