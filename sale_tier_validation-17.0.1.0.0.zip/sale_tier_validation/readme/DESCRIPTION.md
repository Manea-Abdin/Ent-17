This module extends the functionality of Sale Orders to support a tier
validation process.
