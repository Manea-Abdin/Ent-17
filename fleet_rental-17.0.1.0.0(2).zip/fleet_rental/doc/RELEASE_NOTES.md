## Module <fleet_rental>

#### 06.03.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit for Fleet Rental Management
