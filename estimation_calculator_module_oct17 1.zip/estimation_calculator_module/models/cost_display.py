from odoo import models, fields, api

class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    cost = fields.Float(string='Unit Cost', compute='_compute_cost')

    @api.depends('product_id')
    def _compute_cost(self):
        for line in self:
            line.cost = line.product_id.standard_price if line.product_id else 0.0
