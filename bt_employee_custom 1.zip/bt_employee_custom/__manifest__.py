{
    'name': 'Employee Custom',
    'version': '17.0.0.0',
    'category': 'Employees',
    'summary': 'Employee custom data'
               "Renamed string of coach field to supervisor inside employees form,"
               "Added active users filter in employees module.",
    'author': 'Biztras',
    'website': 'https://biztras.com/',
    'depends': [
        'base', 'hr_recruitment', 'hr'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/employee_custom.xml'
    ],
    "application": False,
    'license': 'OEEL-1',
}
