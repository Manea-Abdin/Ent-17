from odoo import models, fields, api


class EmployeeClass(models.Model):
    _name = 'bt.employee.class'
    _description = "BT Employee Class"

    name = fields.Char('Class')


class EmployeeReligion(models.Model):
    _name = 'bt.employee.religion'
    _description = "BT Employee Religion"

    name = fields.Char('Religion')


class EmployeeDivision(models.Model):
    _name = 'bt.employee.division'
    _description = "BT Employee Division"

    name = fields.Char('Employee Division')


class EmployeeCustom(models.Model):
    _inherit = 'hr.employee'

    employee_class = fields.Many2one('bt.employee.class', 'Employee Class')
    employee_religion = fields.Many2one('bt.employee.religion', 'Employee Religion')
    employee_division = fields.Many2one('bt.employee.division', 'Employee Division')
    joining_date = fields.Date('Joining Date')
    passport_expiry_date = fields.Date('Passport Expiry')
    passport_issue_date = fields.Date('Passport Issue Date')
    emiratesid_expiry_date = fields.Date('Emirates ID Expiry')
    visa_issue_date = fields.Date('Visa Issue')
    residence_visa = fields.Many2one('res.country.state', 'Residence Visa')
    passport_issued_at = fields.Many2one('res.country.state', 'Passport Issued At')
    emirates_id_at = fields.Many2one('res.country.state', 'Emirates ID At')
    employee_id_no = fields.Char("Employee ID")
    driving_license_no = fields.Char("Driving License")
    license_issue_date = fields.Date('License Issue')
    license_expiry_date = fields.Date('License Expiry')
    license_issue_at = fields.Many2one('res.country.state', 'License Issue At')
    visa_reference_at = fields.Many2one('res.country.state', 'Visa Reference At')
    labour_contract_expiry = fields.Date('Labour Contract Expiry')
    labour_card_no = fields.Char("Labour Card Number", required=True)
    active_employee = fields.Boolean(string="Active Employee")
    coach_id = fields.Many2one(
        'hr.employee', 'Supervisor', compute='_compute_coach', store=True, readonly=False,
        check_company=True,
        help='Select the "Employee" who is the coach of this employee.\n'
             'The "Coach" has no specific rights or responsibilities by default.')

    _sql_constraints = [
        ('employee_id_no',
         'unique(field)',
         'Employee ID must be unique...!')
    ]
