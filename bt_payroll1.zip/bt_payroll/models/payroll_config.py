from odoo import models, fields, api


class HRContract(models.Model):
    _inherit = "hr.contract"

    fuel_allowance = fields.Monetary(string="Fuel Allowance")
    food_allowance = fields.Monetary(string="Food Allowance")
    air_ticket_allowance = fields.Monetary(string="Air Ticket Allowance")
    remote_area_allowance = fields.Monetary(string="Remote Area Allowance")
    general_allowance = fields.Monetary(string="General Allowance")

