
{
    'name': 'Payroll Custom',
    'version': '17.0',
    'category': 'Payroll',
    'description': "Added fields inside Salary Information tab of Employees ",
    'website': 'https://biztras.com/',
    'author' : 'Biztras',
    'depends': ['base', 'hr_contract', 'l10n_ae_hr_payroll'],
    'data': [
        'views/payroll_config_view.xml',
    ],
    'installable': True,
    'auto_install': True,
    'application': True,
    'license': 'OEEL-1',
}
