from odoo import models

class EstimationCalculator(models.AbstractModel):
    _name = 'report.estimation_calculator_module.report_estimatecalc'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, jobs):
        bold = workbook.add_format({'bold': True})
        format_1 = workbook.add_format({'bold': True, 'align': 'center'})

        sheet = workbook.add_worksheet('Estimation Calculation')
        sheet.set_column('A:I', 20)  # Extend to 9 columns

        row = 0
        col = 0

        # Header
        sheet.merge_range(row, col, row, col + 8, 'Estimation Calculation', format_1)

        row += 1
        headers = ['Products', '0-1000', '1001-3000', '3001-5000', '5001-10000',
                   '10001-25000', '25001-50000', '50001-100000', 'Above 100001']
        for index, header in enumerate(headers):
            sheet.write(row, col + index, header, bold)

        row += 1
        print(jobs)
        for job in jobs.job_impress_line_id:

            for product in job.product_id:  # Assuming job.product_id is the list of products in the job
                print(product)
                sheet.write(row, col, product.name)  # Write product name
                imprint = self.env['estimation.calculator'].search([('product_id', '=', product.id)])
                # sheet.write(row, col + 1, imprint.fixed_one)  # Placeholder: write quantity in range 0-1000
                # sheet.write(row, col + 1, (imprint.dynamic_one))  # Placeholder: write quantity in range 0-1000
                if imprint:
                    combined_value = f"{imprint.fixed_one} + ({imprint.dynamic_one})"
                    sheet.write(row, col + 1, combined_value)
                    combined_value = f"{imprint.fixed_three} + ({imprint.dynamic_three})"
                    sheet.write(row, col + 2, combined_value)
                    combined_value = f"{imprint.fixed_five} + ({imprint.dynamic_five})"
                    sheet.write(row, col + 3, combined_value)
                    combined_value = f"{imprint.fixed_ten} + ({imprint.dynamic_ten})"
                    sheet.write(row, col + 4, combined_value)
                    combined_value = f"{imprint.fixed_twentyfive} + ({imprint.dynamic_twentyfive})"
                    sheet.write(row, col + 5, combined_value)
                    combined_value = f"{imprint.fixed_fifty} + ({imprint.dynamic_fifty})"
                    sheet.write(row, col + 6, combined_value)
                    combined_value = f"{imprint.fixed_lakh} + ({imprint.dynamic_lakh})"
                    sheet.write(row, col + 7, combined_value)
                    combined_value = f"{imprint.fixed_lakh_abv} + ({imprint.dynamic_lakh_abv})"
                    sheet.write(row, col + 8, combined_value)


                # sheet.write(row, col + 2, product.qty_1001_3000)  # Placeholder: write quantity in range 1001-3000
                # sheet.write(row, col + 3, product.qty_3001_5000)  # Placeholder: write quantity in range 3001-5000
                # Add other ranges as required
                row += 1

        # Data rows
        # for appointment in appointments:
        #     # Assuming appointment has relevant fields to fill in
        #     sheet.write(row, col, appointment.product_id.name or '')  # Product name
        #     sheet.write(row, col + 1, appointment.qty_0_1000 or 0)   # Fill appropriate data
        #     sheet.write(row, col + 2, appointment.qty_1001_3000 or 0)
        #     sheet.write(row, col + 3, appointment.qty_3001_5000 or 0)
        #     sheet.write(row, col + 4, appointment.qty_5001_10000 or 0)
        #     sheet.write(row, col + 5, appointment.qty_10001_25000 or 0)
        #     sheet.write(row, col + 6, appointment.qty_25001_50000 or 0)
        #     sheet.write(row, col + 7, appointment.qty_50001_100000 or 0)
        #     sheet.write(row, col + 8, appointment.qty_above_100001 or 0)
        #     row += 1


#
# from odoo import models
#
# class JobCostingReportXlsx(models.AbstractModel):
#     _name = 'report.job_costing_module.report_jobcosting'
#     _inherit = 'report.report_xlsx.abstract'
#
#     def generate_xlsx_report(self, workbook, data, jobs):
#         bold = workbook.add_format({'bold': True})
#         format_1 = workbook.add_format({'bold': True})
#
#         sheet = workbook.add_worksheet('Job Costing Report')
#         sheet.set_column('A:I', 20)  # Extend to 9 columns if needed
#
#         row = 0
#         col = 0
#
#         # Header
#         sheet.merge_range(row, col, row, col + 8, 'Job Costing', format_1)
#
#         row += 1
#         headers = ['Job', '0-1000', '1001-3000', '3001-5000', '5001-10000',
#                    '10001-25000', '25001-50000', '50001-100000', 'Above 100001']
#         for index, header in enumerate(headers):
#             sheet.write(row, col + index, header, bold)
#
#         row += 1
#
#         # Data rows
#         for job in jobs:
#             # Assuming job has relevant fields to fill in
#             sheet.write(row, col, job.name or '')  # Job name
#             sheet.write(row, col + 1, job.cost_0_1000 or 0)   # Fill appropriate data
#             sheet.write(row, col + 2, job.cost_1001_3000 or 0)
#             sheet.write(row, col + 3, job.cost_3001_5000 or 0)
#             sheet.write(row, col + 4, job.cost_5001_10000 or 0)
#             sheet.write(row, col + 5, job.cost_10001_25000 or 0)
#             sheet.write(row, col + 6, job.cost_25001_50000 or 0)
#             sheet.write(row, col + 7, job.cost_50001_100000 or 0)
#             sheet.write(row, col + 8, job.cost_above_100001 or 0)
#             row += 1
