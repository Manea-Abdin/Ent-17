# # from odoo
#
# from odoo import models, fields, api,_
# from odoo.exceptions import UserError
#
# class CrmLead(models.Model):
#     _inherit = 'crm.lead'
#
#     def action_sale_quotations_new(self):
#         print("11111111111111111111111111111")
#         action = super(CrmLead, self).action_sale_quotations_new()
#         quotation = self.env['sale.order'].search([('opportunity_id', '=', self.id)])
#         if quotation:
#             raise UserError(_("Quotation already exists for this lead."))
#
#         estimation_model = self.env['job.costing']
#         # Update this line with the correct field name
#         approved_estimation = estimation_model.search( [('lead_id', '=', self.id), ('state', '=', 'approve')])  # Change 'crm_id' to 'lead_id' or the actual field name
#         print(approved_estimation,"0000000000000000000000000000000000000000000000")
#         if approved_estimation:
#             final_product = approved_estimation[0].final_product1
#             if final_product:
#                 quantity = approved_estimation[0].quantity
#                 product_uom = final_product.uom_id.id
#
#                 prod = self.env['product.product'].search(
#                     [('product_tmpl_id', '=', final_product.id)])
#                 print(action)
#                 if prod:
#                     prod= prod[0]
#                 # action['context'] = dict(action.get('context', {}))
#                 context = dict(self.env.context)
#                 vals = []
#                 vals.append(fields.Command.create({
#                     'product_template_id': final_product.id,
#                     'product_uom':final_product.uom_id.id,
#                     'product_id': prod.id,
#                     'name': prod.name,
#                     'product_uom_qty': quantity,
#                     'price_unit': approved_estimation[0].total/quantity,
#                     }))
#                 action['context']['default_order_line'] =vals
#                 print(action,"123456789012345678")
#
#         return action


from odoo import models, fields, api, _
from odoo.exceptions import UserError


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    # def action_new_quotation(self):
    #     action = self.env["ir.actions.actions"]._for_xml_id("sale_crm.sale_action_quotations_new")
    #     action['context'] = self._prepare_opportunity_quotation_context()
    #     action['context']['search_default_opportunity_id'] = self.id
    #     action['context']['partner_id'] = self.partner_id.id
    #     action['context']['active_test'] = True
    #     return action


    def action_sale_quotations_new(self):
        # Call the original method to generate the base action
        action = super(CrmLead, self).action_sale_quotations_new()

        # Search for all approved estimations related to this lead
        approved_estimations = self.env['job.costing'].search([('lead_id', '=', self.id), ('state', '=', 'approve')])

        if approved_estimations:
            vals = []
            for estimation in approved_estimations:
                final_product = estimation.final_product1
                if final_product:
                    # Extract quantity and UOM from the approved estimation
                    quantity = estimation.quantity
                    product_uom = final_product.uom_id.id

                    # Get the product associated with the template
                    product = self.env['product.product'].search([('product_tmpl_id', '=', final_product.id)], limit=1)

                    if product:
                        # Append each order line for the sale order
                        vals.append(fields.Command.create({
                            'product_template_id': final_product.id,
                            'product_uom': product_uom,
                            'product_id': product.id,
                            'name': product.name,
                            'product_uom_qty': quantity,
                            'price_unit': estimation.total /quantity,
                        }))

            # Update the context with default order lines if any approved estimations are found
            if vals:
                context = dict(self.env.context)
                context.update({'default_order_line': vals})
                context.update({'default_partner_id': self.partner_id.id})
                action['context'] = context

        return action


